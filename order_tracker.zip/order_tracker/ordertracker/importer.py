"""Bulk CSV import with row-by-row validation and an error log."""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from .logic import OrderBook

REQUIRED = ["customer", "item", "category", "quantity", "unit_price",
            "order_date", "due_date"]


def import_csv(book: OrderBook, csv_path, log_path) -> tuple[int, list[str]]:
    """Return (imported_count, error_lines). Valid rows are kept even if others fail."""
    csv_path, log_path = Path(csv_path), Path(log_path)
    errors: list[str] = []
    imported = 0
    try:
        fh = open(csv_path, newline="", encoding="utf-8-sig")
    except OSError as exc:
        return 0, [f"Cannot open file: {exc}"]
    with fh:
        reader = csv.DictReader(fh)
        header = [h.strip().lower() for h in (reader.fieldnames or [])]
        missing = [c for c in REQUIRED if c not in header]
        if missing:
            return 0, [f"Missing required column(s): {', '.join(missing)}"]
        seen = {(o.customer.lower(), o.item.lower(), o.order_date) for o in book.orders}
        for line_no, raw in enumerate(reader, start=2):
            row = {(k or "").strip().lower(): (val or "").strip() for k, val in raw.items()}
            try:
                key = (row["customer"].lower(), row["item"].lower(), row["order_date"])
                if key in seen:
                    raise ValueError("duplicate of an existing order")
                book.add(row["customer"], row["item"], row["category"],
                         row["quantity"], row["unit_price"], row["order_date"],
                         row["due_date"], row.get("notes", ""),
                         row.get("status") or "placed", save=False)
                seen.add(key)
                imported += 1
            except ValueError as exc:
                errors.append(f"Row {line_no}: {exc}")
    if imported:
        book.save()
    stamp = datetime.now().isoformat(timespec="seconds")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "a", encoding="utf-8") as lf:
        lf.write(f"[{stamp}] {csv_path.name}: {imported} imported, {len(errors)} rejected\n")
        for e in errors:
            lf.write(f"    {e}\n")
    return imported, errors
