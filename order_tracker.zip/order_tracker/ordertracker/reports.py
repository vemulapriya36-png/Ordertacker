"""Summary analytics and multi-format export (Markdown, text, CSV)."""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path
from statistics import mean

from .models import Order, STATUSES

HIGH_VALUE_LIMIT = 10_000.00   # anomaly threshold for warnings


def compute_summary(orders: list[Order], today: date | None = None) -> dict:
    today = today or date.today()
    live = [o for o in orders if o.status != "cancelled"]
    revenue = round(sum(o.total for o in live), 2)
    by_status = Counter(o.status for o in orders)
    cat_rev: dict[str, float] = defaultdict(float)
    cust_rev: dict[str, float] = defaultdict(float)
    for o in live:
        cat_rev[o.category] += o.total
        cust_rev[o.customer] += o.total
    days = []
    for o in orders:
        d = o.delivered_on()
        if d:
            days.append((date.fromisoformat(d) - date.fromisoformat(o.order_date)).days)
    monthly = Counter(o.order_date[:7] for o in orders)
    delivered = by_status.get("delivered", 0)
    not_cancelled = len(orders) - by_status.get("cancelled", 0)
    return {
        "generated": today.isoformat(),
        "total_orders": len(orders),
        "by_status": {s: by_status.get(s, 0) for s in STATUSES},
        "revenue": revenue,
        "avg_order_value": round(revenue / len(live), 2) if live else 0.0,
        "avg_fulfilment_days": round(mean(days), 1) if days else None,
        "delivery_rate": round(100 * delivered / not_cancelled, 1) if not_cancelled else 0.0,
        "overdue_count": sum(1 for o in orders if o.is_overdue(today)),
        "high_value_count": sum(1 for o in orders if o.total >= HIGH_VALUE_LIMIT),
        "category_revenue": dict(sorted(cat_rev.items(), key=lambda kv: -kv[1])),
        "top_customers": sorted(cust_rev.items(), key=lambda kv: -kv[1])[:3],
        "monthly_orders": dict(sorted(monthly.items())),
    }


def _bar(n: int, biggest: int, width: int = 24) -> str:
    return "█" * max(1, round(width * n / biggest)) if n else ""


def format_text(s: dict) -> str:
    fd = s["avg_fulfilment_days"]
    L = [f"ORDER SUMMARY  (as of {s['generated']})", "=" * 50,
         f"Total orders        : {s['total_orders']}",
         f"Revenue (excl. canc): {s['revenue']:,.2f}",
         f"Average order value : {s['avg_order_value']:,.2f}",
         f"Delivery rate       : {s['delivery_rate']}%",
         f"Avg fulfilment days : {fd if fd is not None else 'n/a'}",
         f"Overdue orders      : {s['overdue_count']}",
         f"High-value orders   : {s['high_value_count']} (>= {HIGH_VALUE_LIMIT:,.0f})",
         "", "Orders by status", "-" * 50]
    biggest = max(s["by_status"].values(), default=0) or 1
    for st, n in s["by_status"].items():
        L.append(f"  {st:<11}{n:>4}  {_bar(n, biggest)}")
    L += ["", "Revenue by category", "-" * 50]
    for c, r in s["category_revenue"].items():
        L.append(f"  {c:<12}{r:>12,.2f}")
    L += ["", "Top customers", "-" * 50]
    for c, r in s["top_customers"]:
        L.append(f"  {c:<22}{r:>12,.2f}")
    L += ["", "Monthly trend (orders placed)", "-" * 50]
    mb = max(s["monthly_orders"].values(), default=0) or 1
    for m, n in s["monthly_orders"].items():
        L.append(f"  {m}  {n:>3}  {_bar(n, mb)}")
    return "\n".join(L)


def format_markdown(s: dict) -> str:
    fd = s["avg_fulfilment_days"]
    L = ["# Order Summary Report", f"_Generated {s['generated']}_", "",
         "| Metric | Value |", "|---|---|",
         f"| Total orders | {s['total_orders']} |",
         f"| Revenue (excl. cancelled) | {s['revenue']:,.2f} |",
         f"| Average order value | {s['avg_order_value']:,.2f} |",
         f"| Delivery rate | {s['delivery_rate']}% |",
         f"| Avg fulfilment days | {fd if fd is not None else 'n/a'} |",
         f"| Overdue orders | {s['overdue_count']} |", "",
         "## Orders by status", "", "| Status | Count |", "|---|---|"]
    L += [f"| {k} | {n} |" for k, n in s["by_status"].items()]
    L += ["", "## Revenue by category", "", "| Category | Revenue |", "|---|---|"]
    L += [f"| {c} | {r:,.2f} |" for c, r in s["category_revenue"].items()]
    L += ["", "## Top customers", ""]
    L += [f"{i}. **{c}** - {r:,.2f}" for i, (c, r) in enumerate(s["top_customers"], 1)]
    L += ["", "## Monthly trend", "", "| Month | Orders |", "|---|---|"]
    L += [f"| {m} | {n} |" for m, n in s["monthly_orders"].items()]
    return "\n".join(L) + "\n"


def export_orders_csv(orders: list[Order], path: Path) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["order_id", "customer", "item", "category", "quantity",
                    "unit_price", "total", "order_date", "due_date", "status", "notes"])
        for o in orders:
            w.writerow([o.order_id, o.customer, o.item, o.category, o.quantity,
                        f"{o.unit_price:.2f}", f"{o.total:.2f}", o.order_date,
                        o.due_date, o.status, o.notes])


def export_all(orders: list[Order], out_dir: Path, today: date | None = None) -> list[Path]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    s = compute_summary(orders, today)
    tag = datetime.now().strftime("%Y%m%d_%H%M%S")
    files = [out_dir / f"summary_{tag}.md", out_dir / f"audit_{tag}.txt",
             out_dir / f"orders_{tag}.csv"]
    files[0].write_text(format_markdown(s), encoding="utf-8")
    log = [format_text(s), "", "AUDIT LOG (status history)", "-" * 50]
    for o in orders:
        for h in o.history:
            log.append(f"{h['at']}  {o.order_id}  -> {h['status']}")
    files[1].write_text("\n".join(log) + "\n", encoding="utf-8")
    export_orders_csv(orders, files[2])
    return files
