"""Generate data/sample_orders.{csv,json} (deterministic) and a bad-rows CSV for import demos."""
import csv
import random
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from ordertracker.models import Order, STATUS_FLOW  # noqa: E402
from ordertracker.storage import save_orders        # noqa: E402

BASE = date(2026, 11, 21)
random.seed(85)
CUSTOMERS = ["Asha Reddy", "Ravi Kumar", "Meera Iyer", "Sanjay Patel", "Lakshmi Nair",
             "Arjun Rao", "Priya Sharma", "Kiran Das", "Neha Gupta", "Vikram Singh"]
CATALOG = [("Wireless Mouse", "electronics", 799), ("USB-C Cable", "electronics", 349),
           ("Bluetooth Speaker", "electronics", 2499), ("Basmati Rice 5kg", "grocery", 620),
           ("Olive Oil 1L", "grocery", 850), ("Cotton T-Shirt", "clothing", 599),
           ("Denim Jacket", "clothing", 2200), ("A4 Notebook Pack", "stationery", 240),
           ("Gel Pens (10)", "stationery", 150), ("Desk Lamp", "home", 1299),
           ("Steel Water Bottle", "home", 450), ("Gift Hamper", "other", 1800)]

rows = []
# edge / boundary cases first
rows += [
    ("Asha Reddy", "Bulk Paper Reams", "stationery", 1000, 0.01, -30, 5, "delivered", "max quantity, min price"),
    ("Vikram Singh", "Studio Laptop", "electronics", 1, 99999.99, -3, 7, "placed", "near max price"),
    ("Neha Gupta", "Same-day Flowers", "other", 2, 300.00, -1, 0, "processing", "due same day as order"),
    ("Kiran Das", "Cancelled Sofa", "home", 1, 18500.00, -20, 10, "cancelled", "customer changed mind"),
    ("Ravi Kumar", "Late Router", "electronics", 3, 2100.00, -40, 5, "shipped", "overdue test"),
]
for i in range(35):
    item, cat, base = random.choice(CATALOG)
    status = random.choices(STATUS_FLOW + ["cancelled"], [3, 3, 3, 10, 1])[0]
    # open orders are recent (few overdue); delivered ones can be older
    age = random.randint(15, 60) if status in ("delivered", "cancelled") else random.randint(1, 9)
    rows.append((random.choice(CUSTOMERS), item, cat, random.randint(1, 4),
                 round(base * random.uniform(0.9, 1.1), 2), -age,
                 random.randint(7, 14), status, ""))

orders = []
for n, (cust, item, cat, qty, price, off, span, status, notes) in enumerate(rows, 1):
    od = BASE + timedelta(days=off)
    due = od + timedelta(days=span)
    path = ["placed"] if status == "cancelled" else STATUS_FLOW[: STATUS_FLOW.index(status) + 1]
    hist, d = [], od
    for st in path:
        hist.append({"status": st, "at": f"{min(d, BASE).isoformat()}T09:00:00"})
        d += timedelta(days=random.randint(1, 4))
    if status == "cancelled":
        hist.append({"status": "cancelled", "at": f"{min(od + timedelta(days=2), BASE).isoformat()}T11:00:00"})
    orders.append(Order(f"ORD-{n:04d}", cust, item, cat, qty, price, od.isoformat(),
                        due.isoformat(), status, notes, hist))

save_orders(ROOT / "data" / "sample_orders.json", orders)
with open(ROOT / "data" / "sample_orders.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["order_id", "customer", "item", "category", "quantity", "unit_price",
                "order_date", "due_date", "status", "notes"])
    for o in orders:
        w.writerow([o.order_id, o.customer, o.item, o.category, o.quantity,
                    f"{o.unit_price:.2f}", o.order_date, o.due_date, o.status, o.notes])

with open(ROOT / "data" / "legacy_import_with_errors.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["customer", "item", "category", "quantity", "unit_price", "order_date", "due_date", "status"])
    w.writerows([
        ["Test Customer", "Good Item A", "home", 2, "499.00", "2026-11-10", "2026-11-17", "placed"],
        ["Test Customer", "Bad Quantity", "home", "abc", "10", "2026-11-10", "2026-11-17", "placed"],
        ["Test Customer", "Zero Qty", "home", 0, "10", "2026-11-10", "2026-11-17", "placed"],
        ["Test Customer", "Bad Date", "home", 1, "10", "2026-13-45", "2026-11-17", "placed"],
        ["Test Customer", "Due Before Order", "home", 1, "10", "2026-11-10", "2026-11-01", "placed"],
        ["", "Missing Customer", "home", 1, "10", "2026-11-10", "2026-11-17", "placed"],
        ["Test Customer", "Bad Category", "toys", 1, "10", "2026-11-10", "2026-11-17", "placed"],
        ["Test Customer", "Good Item B", "grocery", 5, "120.50", "2026-11-11", "2026-11-18", "shipped"],
    ])
print(f"Generated {len(orders)} sample orders.")
